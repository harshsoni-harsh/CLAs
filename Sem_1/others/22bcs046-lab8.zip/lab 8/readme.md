1.c string concatenation with string.h
1.1.c string concatenation without string.h



problem1
Write a C program to insert a string to the existing string based upon the specified position.
example: if the input is “How you”, and the new string to be inserted at the position 4 is “are”, the
output should be “How are you”.

problem2
Write a C program to count the number of vowels and consonants in a given string.

problem3
Write a C program to convert the alternative characters of a given string to lowercase and uppercase
respectively.
example: “Hello how are you” is the input, the output should be “hElLo HoW aRe YoU”

problem4
Write a C program to find whether a given string is a palindrome or not using the recursive
functions.

problem5
In mathematics, the Fibonacci numbers, commonly denoted Fn, form a sequence, the Fibonacci
sequence, in which each number is the sum of the two preceding ones. The sequence commonly
starts from 0 and 1. Starting from 0 and 1, the next few values in the sequence are: 0, 1, 1, 2, 3, 5, 8,
13, 21, 34, 55, 89, 144, ...
Write a C program to print the first N numbers of the Fibonacci series (where N is the number
specified by the user) using Recursion or the Iteration approach. Suppose if the user enters 5, the
program should print the first 5 numbers i.e., 0, 1, 1, 2, 3 of the Fibonacci series.

problem 6
Write a C program to find occurrences of substring in a string.
sample input:
Enter a string : Hello Hello World
Enter a substring : llo
sample output:
llo occurs 2 times in Hello Hello World